Install-PackageProvider -Name NuGet -force
Install-Module -Name NetworkingDsc -force
Install-Module -Name xSystemSecurity -force
#Set-NetFirewallProfile -Profile Domain,Public,Private -Enabled False