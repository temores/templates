Configuration dscconf
{
  param ($MachineName)
  Import-DscResource -ModuleName 'PSDesiredStateConfiguration'
  #Import-DscResource -Module NetworkingDsc
  #Import-DSCResource -Module xSystemSecurity -Name xIEEsc
 # PsDscAllowPlainTextPassword = $true
 #$Credential = New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList ("temores\adrian)", "Azur3p4ssw0rd!")

  Node $MachineName
  {

    LocalConfigurationManager
    {
        ConfigurationMode = 'ApplyAndAutoCorrect'
        RebootNodeIfNeeded = $true
        ActionAfterReboot = 'ContinueConfiguration'
        AllowModuleOverwrite = $true
        ConfigurationModeFrequencyMins = 1
    }

    #Install the IIS Role
    WindowsFeature IIS
    {
      Ensure = "Present"
      Name = "Web-Server"
    }

    #Install ASP.NET 4.5
    WindowsFeature ASP
    {
      Ensure = "Present"
      Name = "Web-Asp-Net45"
    }

     WindowsFeature WebServerManagementConsole
    {
        Name = "Web-Mgmt-Console"
        Ensure = "Present"
    }
    
    WindowsFeature NETFrameworkFeatures
    {
        Name = "NET-Framework-Features"
        Ensure = "Present"
    }

    Group AddADUserToLocalAdminGroup 
    {
      GroupName='Administrators'
      Ensure= 'Present'
      MembersToInclude= "temores\dbadmins"
      
    }

    Registry SetSQLServerAuthenticationMode 
    {
      Ensure = "Present"
      Key = "HKLM:\Software\Microsoft\MSSQLServer\MSSQLServer"
      ValueName = "LoginMode"
      ValueData = "2"
      ValueType = "Dword" 
    }

    #FirewallProfile ConfigurePrivateFirewallProfile
    #    {
    #        Name = 'Private'
    #        Enabled = 'False'    
    #    }

#        FirewallProfile ConfigurePublicFirewallProfile
#        {
#            Name = 'Public'
#            Enabled = 'False'    
#        }

#        xIEEsc EnableIEEscAdmin
#        {
#            IsEnabled = $True
#            UserRole  = "Administrators"
#        }

#        xIEEsc EnableIEEscUser
#        {
#            IsEnabled = $True
#            UserRole  = "Users"
#        }
  } 
}